package com.example.epicture;

class Photo {
    String id;
    String title;
}